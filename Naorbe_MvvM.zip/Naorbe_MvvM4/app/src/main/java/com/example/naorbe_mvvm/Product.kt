package com.example.naorbe_mvvm

data class Product(
    val name: String,
    val price: String,
    val imageRes: Int
)