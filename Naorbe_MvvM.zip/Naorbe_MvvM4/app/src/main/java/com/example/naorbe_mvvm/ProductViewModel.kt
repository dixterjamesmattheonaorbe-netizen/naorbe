package com.example.naorbe_mvvm

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ProductViewModel : ViewModel() {
    private val _products = MutableLiveData<List<Product>>()
    val products: LiveData<List<Product>> = _products

    init {
        loadProducts()
    }

    private fun loadProducts() {
        val itemList = listOf(
            Product("iPhone 12 Pro", "P100", R.drawable.iphone12),
            Product("iPhone 13 Pro", "P100", R.drawable.iphone13),
            Product("iPhone 13 Pro Max", "P100", R.drawable.iphone13max)
        )
        _products.value = itemList
    }
}