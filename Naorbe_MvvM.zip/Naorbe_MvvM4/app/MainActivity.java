public class MainActivity extends appCompatActivity {
    @Override
    protected void onCreate (Bundle savedInsanceState) {
        super.onCreate(savesInsranceState) ;
        setContent
}
